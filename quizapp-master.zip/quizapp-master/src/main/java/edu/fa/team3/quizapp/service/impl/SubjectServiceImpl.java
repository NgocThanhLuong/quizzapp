package edu.fa.team3.quizapp.service.impl;

import edu.fa.team3.quizapp.model.Subject;
import edu.fa.team3.quizapp.repository.SubjectRepository;
import edu.fa.team3.quizapp.service.SubjectService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SubjectServiceImpl implements SubjectService{
    private static final Logger LOGGER = LogManager.getLogger(SubjectServiceImpl.class);
    @Autowired
    private SubjectRepository subjectRepository;


    @Override
    @Transactional
    public Subject addSubject(Subject subject) {
        return subjectRepository.save(subject);
    }

    @Override
    public List<Subject> getAllSubject() {
        LOGGER.info("getAllSubject");
        return subjectRepository.findAll();
    }

    @Override
    public Subject getSubjectById(int subjectId) {
        return subjectRepository.findById(subjectId).orElse(null);
    }
}
