package edu.fa.team3.quizapp.repository;

import edu.fa.team3.quizapp.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Integer> {
    Role findByAuthority(String authority);
}
