package edu.fa.team3.quizapp.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import edu.fa.team3.quizapp.model.pk.ExamId;

import javax.persistence.*;
import java.io.Serializable;

@Entity
public class Exam implements Serializable {
    @Id
    @EmbeddedId
    private ExamId examId;
    private double mark;
    private int rank;

    @ManyToOne
    @MapsId("userId")
    private User user;

    @ManyToOne
    @MapsId("testId")
    private Test test;

    public ExamId getExamId() {
        return examId;
    }

    public void setExamId(ExamId examId) {
        this.examId = examId;
    }

    public double getMark() {
        return mark;
    }

    public void setMark(double mark) {
        this.mark = mark;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Test getTest() {
        return test;
    }

    public void setTest(Test test) {
        this.test = test;
    }
}
