package edu.fa.team3.quizapp.service.impl;

import edu.fa.team3.quizapp.model.Role;
import edu.fa.team3.quizapp.repository.RoleRepository;
import edu.fa.team3.quizapp.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleRepository roleRepository;

    @Override
    public Role findByAuthority(String authority) {
        return roleRepository.findByAuthority(authority);
    }
}
