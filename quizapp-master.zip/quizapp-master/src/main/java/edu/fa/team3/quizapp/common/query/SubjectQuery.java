package edu.fa.team3.quizapp.common.query;

public class SubjectQuery {
    public  static final  String DELETE_ANSWER_BY_QUESTION_ID="delete from  answer where question_id=?";
}
