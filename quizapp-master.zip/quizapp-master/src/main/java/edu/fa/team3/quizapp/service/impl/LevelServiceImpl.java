package edu.fa.team3.quizapp.service.impl;

import edu.fa.team3.quizapp.model.Level;
import edu.fa.team3.quizapp.repository.LevelRepository;
import edu.fa.team3.quizapp.service.LevelService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

@Service
public class LevelServiceImpl implements LevelService {
    private static final Logger LOGGER = LogManager.getLogger(LevelServiceImpl.class);
    @Autowired
    private LevelRepository levelRepository;
    @Autowired
    private EntityManager em;

    @Override
    public List<Level> getAllLevel() {
        LOGGER.info("getAllLevel");
        return levelRepository.findAll();
    }


    @Override
    @Transactional
    public Level addLevel(Level level) {

        return levelRepository.save(level);
    }

    @Override
    public Level getLevelById(int levelId) {
        return levelRepository.findById(levelId).orElse(null);
    }
}
