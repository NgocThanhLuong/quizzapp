package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.model.Level;

import java.util.List;

public interface LevelService {
    /**
     *
     * @param level
     * @return a level saved
     */
    Level addLevel(Level level);

    /**
     *
     * @return list<Level>
     */
    List<Level> getAllLevel();

    /**
     *
     * @param levelId
     * @return a level by levelId
     */
    Level getLevelById(int levelId);
}
