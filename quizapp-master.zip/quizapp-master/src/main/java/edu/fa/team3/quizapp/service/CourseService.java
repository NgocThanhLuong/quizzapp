package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.model.Course;

import java.util.List;

public interface CourseService {
    /**
     *
     * @param course
     * @return  a course is saved
     */
    Course addCourse(Course course);

    /**
     *
     * @return list all course
     */
    List<Course> getAllCourse();

    /**
     *
     * @param subjectId
     * @return list course by subjectId
     */
    List<Course> getAllCourseBySubjectId(int subjectId);

    /**
     *
     * @param id
     * @return a course by id
     */
    Course getCourseById(int id);
}
