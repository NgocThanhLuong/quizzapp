package edu.fa.team3.quizapp.repository;

import edu.fa.team3.quizapp.model.Post;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PostRepository extends JpaRepository<Post,Integer> {
    Page<Post> findAll(Pageable pageable);

    //Find by title and subjectId
    Page<Post> findByTitleLikeAndCourse_Subject_SubjectId(String title,int subjectId,Pageable pageable);

    Page<Post> findByTitleLike(String title,Pageable pageable);

    List<Post> findByCourseCourseId(int courseId);
}
