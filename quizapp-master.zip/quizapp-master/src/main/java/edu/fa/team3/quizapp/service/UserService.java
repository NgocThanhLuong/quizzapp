package edu.fa.team3.quizapp.service;


import edu.fa.team3.quizapp.dto.UserDto;
import edu.fa.team3.quizapp.exception.PasswordMismatchException;
import edu.fa.team3.quizapp.exception.UserExistException;
import edu.fa.team3.quizapp.model.User;

public interface UserService {
    User add(UserDto userDto) throws UserExistException, PasswordMismatchException;
    User findByUserName(String userName);
}
