package edu.fa.team3.quizapp.common;

public class UserPermissionConstants {

    public static final String ROLE_MEMBER = "ROLE_MEMBER";
    public static final String ROLE_ADMIN = "ROLE_ADMIN";
}
