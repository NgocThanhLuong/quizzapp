package edu.fa.team3.quizapp.common;

public class Note {

    public static String NOTE_EXAM_PDF_02 = "Select the correct answer.\r\n" +
            "Note: Each question can have many correct answers. ";
    public static String CMD_RUN_FOXIT = "C:\\Program Files (x86)\\Foxit Software\\Foxit Reader\\FoxitReader.exe";
    public static String CMD_RUN_GOOGLE_CHROME = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe";

}
