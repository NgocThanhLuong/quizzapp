package edu.fa.team3.quizapp.common;

import edu.fa.team3.quizapp.service.impl.PostServiceImpl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoggerSpringBoot {

    public static final  Logger getLoggerSpringBoot(){
        return LogManager.getLogger(LoggerSpringBoot.class);
    }

}
