package edu.fa.team3.quizapp.repository;

import edu.fa.team3.quizapp.model.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<User,Integer> {
    User findByUserName(String userName);
}
