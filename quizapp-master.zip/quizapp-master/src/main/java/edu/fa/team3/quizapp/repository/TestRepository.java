package edu.fa.team3.quizapp.repository;

import edu.fa.team3.quizapp.model.Test;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface TestRepository extends JpaRepository<Test,Integer>{
    List<Test> findAllByCourseCourseId(int courseId);

    @Query(value = "select test_text from test where test_id = ?1", nativeQuery = true)
    String getTestTextByTestId(int testId);
    List<Test> findAllByTestTextLike(String testText);

}
