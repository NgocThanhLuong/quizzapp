package edu.fa.team3.quizapp.repository;

import edu.fa.team3.quizapp.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CourseRepository extends JpaRepository<Course,Integer> {
    List<Course> findAllBySubjectSubjectId(int subjectId);
    Course findByCourseId(int id);
    Course findByCourseName(String courseName);
}
