package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.dto.ExamResultDto;
import edu.fa.team3.quizapp.dto.TestDto;
import edu.fa.team3.quizapp.dto.UserTestDto;
import edu.fa.team3.quizapp.dto.UserTestResult;
import edu.fa.team3.quizapp.model.Test;
import edu.fa.team3.quizapp.model.pk.ExamId;

import java.util.List;

public interface TestService {
    /**
     *
     * @param testId
     * @return a test by id
     */
    Test getById(int testId);

    /**
     *
     * @param testDto
     * @return object save or update
     */
    Test addOrUpdateTest(TestDto testDto);

    /**
     *
     * @param id
     * @return list test by course id
     */
    List<Test> getAllByCourseId(int id);

    /**
     *
     * @param testId
     * @return testText by testId
     */
    String getTestTextByTestId(int testId);

    /**
     *
     * @param userTestDto
     * @return examResultDto
     */
    ExamResultDto doTest(UserTestDto userTestDto);

    /**
     *
     * @return list all test
     */
    List<Test> getAllTest();

    /**
     *
     * @param testId
     * @do {
     *     delete test by id
     * }
     * @return true or false
     */
    boolean deleteById(int testId);

    /**
     *
     * @param testText
     * @return
     */
    List<Test> findByTestTextLike(String testText);
}
