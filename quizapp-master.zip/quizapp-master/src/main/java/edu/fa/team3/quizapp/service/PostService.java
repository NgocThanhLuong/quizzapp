package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.dto.PostDto;
import edu.fa.team3.quizapp.model.Post;
import edu.fa.team3.quizapp.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;


public interface PostService {
    Post addPost(PostDto postDto, User user);
    Page<Post> getAll(Pageable pageable);
    boolean deletePost(int id);
    Post getOneById(int id);
    Page<Post> getByTitleLikeAndCourse_Subject_SubjectId(String title,int subjectId,Pageable pageable);
    Page<Post> getByTitle(String title,Pageable pageable);
    List<Post> getByCourseId(int courseId);
}
