package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.model.Role;

public interface RoleService {
    Role findByAuthority(String authority);
}
