package edu.fa.team3.quizapp.controller;

import edu.fa.team3.quizapp.common.PageTitleConstrants;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class AdminController {
    /**
     *
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/admin",method = RequestMethod.GET)
    public String admin(ModelMap modelMap) {
        modelMap.addAttribute("title", PageTitleConstrants.HOME_PAGE);
        return "admin";
    }
}
