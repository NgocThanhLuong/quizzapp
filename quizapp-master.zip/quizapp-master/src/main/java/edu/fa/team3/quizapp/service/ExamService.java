package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.dto.ExamResultDto;
import edu.fa.team3.quizapp.model.Exam;
import edu.fa.team3.quizapp.model.Test;
import edu.fa.team3.quizapp.model.pk.ExamId;

import java.util.List;

public interface ExamService {
    Exam addExam(Exam exam);
    void deleteExamById(ExamId examId);
    List<Exam> getAllByUserIdAndSubjectId(int userId,int subjectId);
    Exam addExam(ExamResultDto examResultDto,Test test);
}
