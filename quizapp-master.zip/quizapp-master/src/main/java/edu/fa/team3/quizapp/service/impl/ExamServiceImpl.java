package edu.fa.team3.quizapp.service.impl;

import edu.fa.team3.quizapp.dto.ExamResultDto;
import edu.fa.team3.quizapp.model.Exam;
import edu.fa.team3.quizapp.model.Test;
import edu.fa.team3.quizapp.model.pk.ExamId;
import edu.fa.team3.quizapp.repository.ExamRepository;
import edu.fa.team3.quizapp.service.ExamService;
import edu.fa.team3.quizapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class ExamServiceImpl implements ExamService {
    @Autowired
    private ExamRepository examRepository;

    @Autowired
    private UserService userService;

    @Override
    public Exam addExam(Exam exam) {
        return examRepository.save(exam);
    }

    @Override
    public void deleteExamById(ExamId examId) {
        examRepository.deleteById(examId);
    }

    @Override
    public List<Exam> getAllByUserIdAndSubjectId(int userId, int subjectId) {
        return examRepository.findAllByExamId_UserIdAndTestCourseSubjectSubjectId(userId,subjectId);
    }

    @Override
    public Exam addExam(ExamResultDto examResultDto,Test test) {
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        edu.fa.team3.quizapp.model.User userLogged = userService.findByUserName(user.getUsername());
        ExamId examId = new ExamId();
        examId.setUserId(userLogged.getUserId());
        examId.setDateTime(new Date());
        examId.setTestId(test.getTestId());

        Exam exam = new Exam();
        exam.setExamId(examId);
        exam.setMark(examResultDto.getScore());
        exam.setRank(examResultDto.getRank());
        exam.setTest(test);
        exam.setUser(userLogged);

        return examRepository.save(exam);
    }
}
