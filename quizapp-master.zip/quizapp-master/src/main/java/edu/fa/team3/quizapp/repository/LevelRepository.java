package edu.fa.team3.quizapp.repository;

import edu.fa.team3.quizapp.model.Level;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LevelRepository extends JpaRepository<Level,Integer>{
    Level findByLevelName(String levelName);
}
