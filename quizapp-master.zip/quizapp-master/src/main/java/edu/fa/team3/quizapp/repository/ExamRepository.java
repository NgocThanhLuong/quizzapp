package edu.fa.team3.quizapp.repository;

import edu.fa.team3.quizapp.model.Exam;
import edu.fa.team3.quizapp.model.pk.ExamId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExamRepository extends JpaRepository<Exam,ExamId> {
    List<Exam> findAllByExamId_UserIdAndTestCourseSubjectSubjectId(int userId, int subjectId);
}
