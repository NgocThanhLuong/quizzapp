package edu.fa.team3.quizapp.exception;

public class UserExistException extends Exception {
    public UserExistException(String message) {
        super(message);
    }
}
