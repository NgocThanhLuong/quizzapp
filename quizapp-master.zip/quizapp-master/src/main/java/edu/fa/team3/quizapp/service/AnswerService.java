package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.dto.AnswerDto;
import edu.fa.team3.quizapp.model.Answer;
import edu.fa.team3.quizapp.model.Question;

import java.util.List;

public interface AnswerService {

     /**
      *
      * @param answerDto
      * @param questionCreated
      * @return a answer is saved
      */
     Answer addAnswer(AnswerDto answerDto, Question questionCreated);

     /**
      *
      * @param questionId
      * delete answer by question Id
      * @return true or false
      */
     boolean deleteAnswerByQuestionId (int questionId);

     /**
      *
      * @param questionId
      * @return list answer by question id
      */
     List<Answer> getListAnswerByQuestionId(int questionId);

     /**
      *
      * @param questionId
      * @param sequence
      * @return a answer
      */
     Answer getAnswerByQuestionIdAndSequence(int questionId,String sequence);
     boolean deleteAnswerById (int answerId);

     /**
      *
      * @param id
      * @param isCorrect
      * @return list answer
      */
     List<Answer> getAllByQuestionQuestionIdAndCorrectAnswer(int id,boolean isCorrect);
}
