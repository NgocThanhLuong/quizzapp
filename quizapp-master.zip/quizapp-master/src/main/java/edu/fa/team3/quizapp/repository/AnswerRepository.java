package edu.fa.team3.quizapp.repository;

import edu.fa.team3.quizapp.model.Answer;
import edu.fa.team3.quizapp.model.Question;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AnswerRepository extends JpaRepository<Answer,Integer>{
    List<Answer> findAllByQuestionQuestionId(int id);
    Answer findByQuestionQuestionIdAndSequence(int questionId,String sequence);
    List<Answer> findAllByQuestionQuestionIdAndCorrectAnswer(int id,boolean isCorrect);
}
