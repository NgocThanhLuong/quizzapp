package edu.fa.team3.quizapp.controller.admin;

public class AdminSubjectController {
}
