package edu.fa.team3.quizapp.service;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class QuestionServiceTest {

    @Autowired
    private QuestionService questionService;

    @Before
    public void setUp(){

    }

    @After
    public void tearDown(){

    }

    @Test
    public void testTindByQuestionId(){
        Assert.assertNotNull(questionService.findByQuestionId(1));
    }

    @Test
    public void testDeleteQuestionById(){
        Assert.assertTrue(questionService.deleteQuestion(1));
    }

    @Test
    public void testFindAllQuestion(){
        Pageable pageable = PageRequest.of(1, 10, Sort.by("questionId").descending());
        Assert.assertTrue(questionService.findAll(pageable).getTotalElements()>0);
    }

    @Test
    public void testFindByLevelId(){
        Pageable pageable = PageRequest.of(1, 10, Sort.by("questionId").descending());
        Assert.assertTrue(questionService.findByLevel_LevelId(1,pageable).getTotalElements()>0);
    }

    @Test
    public void testFindBySubjectId(){
        Pageable pageable = PageRequest.of(1, 10, Sort.by("questionId").descending());
        Assert.assertTrue(questionService.findByCourse_Subject_SubjectId(1,pageable).getTotalElements()>0);
    }

    @Test
    public void testFindByQuestionText(){
        Pageable pageable = PageRequest.of(1, 10, Sort.by("questionId").descending());
        Assert.assertTrue(questionService.findByQuestionTextLike("%java%",pageable).getTotalElements()>0);
    }


}
