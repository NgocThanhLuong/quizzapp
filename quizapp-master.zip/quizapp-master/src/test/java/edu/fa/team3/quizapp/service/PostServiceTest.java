package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.dto.PostDto;
import edu.fa.team3.quizapp.model.Course;
import edu.fa.team3.quizapp.model.User;
import edu.fa.team3.quizapp.repository.PostRepository;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class PostServiceTest {
    @Autowired
    private PostService postService;

    @Autowired
    private UserService userService;

    @Before
    public void setUp(){

    }

    @After
    public void tearDown(){

    }

    @Test
    public void testAddPostWithCourseEmpty(){

        PostDto postDto = new PostDto();
        postDto.setCourseId(99);
        postDto.setPostContent("Hello ");
        postDto.setPostTitle("Test add post");

        User user = userService.findByUserName("admin");

        Assert.assertNull(postService.addPost(postDto,user));
    }

    @Test
    public void testAddPost(){
        PostDto postDto = new PostDto();
        postDto.setCourseId(1);
        postDto.setPostContent("Hello");
        postDto.setPostTitle("Test add post");

        User user = userService.findByUserName("admin");

        Assert.assertNotNull(postService.addPost(postDto,user));
    }

    @Test
    public void testGetAllPost(){
        Pageable pageable = PageRequest.of(1, 10, Sort.by("postId").descending());
        Assert.assertTrue(postService.getAll(pageable).getTotalElements()>0);
    }

    @Test
    public void testDeletePost(){
        Assert.assertTrue(postService.deletePost(14));
    }

    @Test
    public void testDeletePostWithPostIdNotFound(){
        Assert.assertFalse(postService.deletePost(99));
    }

    @Test
    public void testGetOneById(){
        Assert.assertNotNull(postService.getOneById(17));
    }

    @Test
    public void testGetOneByIdWithIdNotFound(){
        Assert.assertNull(postService.getOneById(99));
    }

    @Test
    public void testGetByTitle(){
        Pageable pageable = PageRequest.of(1, 10, Sort.by("postId").descending());
        Assert.assertTrue(postService.getByTitle("What is Java",pageable).getTotalElements()>0);
    }


}
