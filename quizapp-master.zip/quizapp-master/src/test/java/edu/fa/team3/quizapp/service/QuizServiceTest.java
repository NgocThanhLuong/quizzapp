package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.dto.UserQuestionDto;
import edu.fa.team3.quizapp.dto.UserTestDto;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class QuizServiceTest {
    @Autowired
    private TestService testService;

    @Before
    public void setUp(){

    }

    @After
    public void tearDown(){

    }

    @Test
    public void testGetQuizById(){
        Assert.assertNotNull(testService.getById(1));
    }

    @Test
    public void testGetAllByCourseId(){
        Assert.assertTrue(testService.getAllByCourseId(1).size()>0);
    }

    @Test
    public void testDeleteQuiz(){
        Assert.assertTrue(testService.deleteById(1));
    }

    @Test
    public void testGetAllTest(){
        Assert.assertTrue(testService.getAllTest().size()>0);
    }

    @Test
    public void testDoTest(){
        UserTestDto userTestDto = new UserTestDto();
        userTestDto.setTestId(6);

        UserQuestionDto userQuestionDto = new UserQuestionDto();
        userQuestionDto.setQuestionId(1);

        List<String> sequences = new ArrayList<>();
        sequences.add("C");
        sequences.add("B");
        userQuestionDto.setSequenceList(sequences);

        List<UserQuestionDto> userQuestionDtos = new ArrayList<>();
        userQuestionDtos.add(userQuestionDto);

        userTestDto.setQuestionList(userQuestionDtos);

        Assert.assertNotNull(testService.doTest(userTestDto));

    }
}
