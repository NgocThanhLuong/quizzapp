package edu.fa.team3.quizapp.service;

import edu.fa.team3.quizapp.dto.UserDto;
import edu.fa.team3.quizapp.exception.PasswordMismatchException;
import edu.fa.team3.quizapp.exception.UserExistException;
import edu.fa.team3.quizapp.model.Role;
import edu.fa.team3.quizapp.model.User;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RunWith(SpringRunner.class)
@SpringBootTest
@Transactional
public class UserServiceTest {
    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    @Before
    public void setUp(){

    }

    @After
    public void tearDown(){

    }

    @Test
    public void testGetUserByUserName(){
        Assert.assertNotNull(userService.findByUserName("admin"));
    }

    @Test
    public void testAddUser() throws UserExistException, PasswordMismatchException {

        UserDto userDto = new UserDto();
        userDto.setUserName("admin1");
        userDto.setPassword("123456");
        userDto.setRePassword("123456");

        Assert.assertTrue(userService.add(userDto).getUserId()>0);
    }

    @Test(expected = UserExistException.class)
    public void testAddUserWithExistUserName() throws UserExistException, PasswordMismatchException {
        UserDto userDto = new UserDto();
        userDto.setUserName("admin");
        userDto.setPassword("123456");
        userDto.setRePassword("123456");
        Assert.assertTrue(userService.add(userDto).getUserId()>0);
    }

    @Test(expected = PasswordMismatchException.class)
    public void testAddUserWithPasswordAndConfirmationPasswordNotSame() throws UserExistException, PasswordMismatchException {
        UserDto userDto = new UserDto();
        userDto.setUserName("admin1");
        userDto.setPassword("123456");
        userDto.setRePassword("1234567");
        Assert.assertTrue(userService.add(userDto).getUserId()>0);
    }


}
